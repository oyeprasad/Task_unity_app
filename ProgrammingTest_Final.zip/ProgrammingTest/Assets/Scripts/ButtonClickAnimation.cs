﻿using UnityEngine;

public class ButtonClickAnimation : MonoBehaviour {
	
	public void OnPointerDown(){
		transform.localScale = new Vector3 (1.2f, 1.2f, 1.2f);
	}

	public void OnPointerUp(){
		transform.localScale = new Vector3 (1, 1, 1);
	}
}
