﻿/*********************
 * This class is responsible for retrieve data from server,  
 * Converting to Json Data 
 * and then populate the list of languages.
 * 
 * ***************************/

using UnityEngine;
using SimpleJSON;
using System;
using UnityEngine.UI;
using System.Collections;

public class DataController : MonoBehaviour {

	public string url = "https://private-5b1d8-sampleapi187.apiary-mock.com/questions";
	public Button refreshButton;
	public Text title;
	public GameObject languageBlock;

	void OnEnable(){
		ButtonClickHandler.refreshClicked += OnRefreshButtonClicked; 
	}

	void Start(){
		StartCoroutine (LoadData ());
	}
	void Update(){
		//Close the application whenever user pressed back button from mobile. 
		if (Input.GetKey (KeyCode.Escape))
			Application.Quit ();
	}

	//This methode is called whenever refresh button pressed
	private void OnRefreshButtonClicked(){
		StartCoroutine (LoadData ());
	}

	// This coroutine is responsible for download data using www class. 
	IEnumerator LoadData(){
		refreshButton.interactable = false;
		WWW www = new WWW (url);

		//print(www.progress);
		yield return www;
		if (www.isDone) {
			refreshButton.interactable = true;
		}
		if (www.error == null) {
			ProcessJsonData (www.text);
		} else {
			Debug.LogError (www.error);
		}
			
	}

	// Process string data to object using Json
	private void ProcessJsonData(string _jsonData = ""){
		JSONNode data = JSONArray.Parse(_jsonData);
		RefreshPanel (data);
	}
		
	//All the language present at server will be loaded and respective UI
	// will be created from this method.
	private void RefreshPanel(JSONNode _data){
		title.text = _data[0]["question"].Value;
		ClearPreviousData ();
		GameObject tmp;
		LanguageItem langItem;
		for (int i = 0; i < _data[0] [2].Count; i++) {
			tmp = Instantiate(languageBlock, Vector3.zero, Quaternion.identity) as GameObject;
			langItem = tmp.GetComponent<LanguageItem>() as LanguageItem; 
			langItem.PopulateDetails (_data [0] [2] [i] [0].Value, _data [0] [2] [i] [1].Value);
			tmp.transform.SetParent (transform);
			tmp.transform.localScale = Vector3.one;
		}
	}
		
	private void ClearPreviousData(){
		for(int i = 0; i < transform.childCount; i++){
			Destroy(transform.GetChild(i).gameObject); //ransform.GetChild(i));
		}
	}
}