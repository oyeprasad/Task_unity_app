﻿using UnityEngine;

public class ButtonClickHandler : MonoBehaviour {

	public delegate void RefreshClicked ();
	public static event RefreshClicked refreshClicked;

	public void RefreshButtonUp(){
		refreshClicked ();
	}
}
