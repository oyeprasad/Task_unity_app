﻿using UnityEngine;
using UnityEngine.UI;

public class LanguageItem : MonoBehaviour {

	[SerializeField] private Text languageNameText;
	[SerializeField] private Text voteCountText;

	public void PopulateDetails(string _name, string _voteCount){
		languageNameText.text = _name;
		voteCountText.text = _voteCount;
	}
		
}
